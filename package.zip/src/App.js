import "./App.css";
import Main from "./component";

function App() {
  return (
    <div className="App">
      <div className="main">
        <Main />
      </div>
    </div>
  );
}

export default App;
